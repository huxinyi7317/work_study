import unittest
from UI.tools.HTMLTestRunner import HTMLTestRunner

case = unittest.defaultTestLoader.discover("case","test_*")
filepath = 'bg/bg.html'
bt = 'UI测试报告'
ms = '测试报告描述'
with open(filepath,"wb") as f:

    ht = HTMLTestRunner(stream=f,title=bt,description=ms)
    ht.run(case)