from selenium import webdriver
import time
from UI.tools.dw import ElementOperition
from UI.tools.case_config import Test


class DataClass():#页面元素数据类

    def __init__(self):
        self.longin_yuansu = [('xpath','//input[@placeholder="请输入账号"]')
        ,('xpath','//input[@placeholder="请输入密码"]')
        ,('xpath','//*[@id="app"]/div[2]/div[2]/div[1]/form/button')
        ,('xpath','//*[@id="app"]/div[1]/div/div[1]/div/div[3]/img')
        ,('xpath','//*[@id="app"]/div[2]/div[2]/div[1]/div/div[4]/div')
        ,('xpath','//*[@id="app"]/div[3]/div[1]/div[2]/div[1]/div/div[4]/div/span/div[2]/div[1]/div[1]/div/div')
        ,('xpath','//*[@id="app"]/div[3]/div[1]/div[2]/div[1]/div/div[4]/div/span/div[2]/div[1]/div[1]/div/iframe')#聊天输入框
        ,('xpath','/html/body')
        ,('xpath','//*[@id="app"]/div[3]/div[1]/div[2]/div[1]/div/div[4]/div/span/div[2]/div[2]/button/i')]
    
        self.longin_test_data = {'账号':15179745797,'密码':111111}

