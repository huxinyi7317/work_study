from selenium import webdriver
import time
from UI.tools.dw import ElementOperition
from UI.tools.case_config import Test


class DataClass():#页面元素数据类

    def __init__(self):
        self.longin_yuansu = {'账号输入框':('xpath','//input[@placeholder="请输入账号"]')
        ,'密码输入框':('xpath','//input[@placeholder="请输入密码"]')   
        ,'登入按钮':('xpath','//span[text()="登录"]')    
        ,'购物车':('xpath','//*[@id="app"]/div[1]/div/div[1]/div/div[4]/div[1]')    
        ,'智能招标':('xpath','//div[@title="智能招标"]') 
        ,'新建智能招标':('xpath','//span[text()="新建智能招标"]')
        ,'上传招标公告':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[3]/div/form/div[1]/div/div/input')    
        ,'上传招标邀请函':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[3]/div/form/div[2]/div/div/input')  
        ,'上传招标文件':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[3]/div/form/div[3]/div/div/input')   
        ,'上传招标技术标准':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[3]/div/form/div[4]/div/div/input')    
        ,'招标名称':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[1]/div/form/div[1]/div/div/input')   
        ,'项目名称':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[1]/div/form/div[2]/div/div/input')    
        ,'回标截止时间':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[1]/div/form/div[3]/div/div/input')   
        ,'备注信息':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[1]/div/form/div[4]/div/div/textarea') 
        ,'副文本编辑器':('xpath','//*[@id="ueditor_0"]')
        ,'副文本编辑区域':('xpath','/html/body')
        ,'下一步':('xpath','//span[text()="下一步"]') 
        ,'上一步':('xpath','//span[text()="上一步"]') 
        ,'商品分类':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[1]/div[2]/form/div/div/div/div/input')
        ,'精装材料':('xpath','//span[text()="精装材料"]')
        ,'瓷砖':('xpath','//span[text()="瓷砖"]')
        ,'抛光砖':('xpath','//span[text()="抛光砖"]')
        ,'选择商品分类':('xpath','//span[text()="精装材料 / 瓷砖 / 抛光砖"]') 
        ,'添加产品':('xpath','//span[text()="添加产品"]')  
        ,'商品单位':('xpath','/html/body/div[6]/div/div[2]/div/div[1]/div[2]/div[1]/div/div[1]/div/div[1]/input')   
        ,'室内地砖':('xpath','/html/body/div[9]/div/div[2]/div/div[1]/div[2]/div[1]/div/div[2]/div[2]/div[1]/label/span[1]/span')   
        ,'内墙':('xpath','/html/body/div[9]/div/div[2]/div/div[1]/div[2]/div[1]/div/div[2]/div[2]/div[2]/label/span[1]/span')   
        ,'200*200':('xpath','/html/body/div[9]/div/div[2]/div/div[2]/div[2]/div[1]/div/div/div[2]/div[1]/label/span[1]/span')   
        ,'300*450':('xpath','/html/body/div[9]/div/div[2]/div/div[2]/div[2]/div[1]/div/div/div[2]/div[5]/label/span[1]/span')
        ,'确定':('xpath','//span[text()="确定"]') 
        ,'提交':('xpath','//span[text()="提交"]') 
        ,'订单搜索输入框':('xpath','//*[@id="app"]/div[3]/div[1]/div[2]/div[1]/div[4]/input') 
        ,'查看详情':('xpath','//a[text()="查看详情"]') 
        ,'实收金额输入框':('xpath','//*[@id="collectionAmont"]') 
        ,'弹窗确认收款':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[11]/div/div[2]/div/div[1]/div/div/div[3]/button[2]/span') 
        ,'判断页面元素':('xpath','//span[@title="买入订单"]')
        ,'关联买入订单':('xpath','//span[@class="active" and text()="买入订单"]')
        ,'付预付款':('xpath','//span[text()="付预付款"]')
        ,'test_':('xpath','/html/body/div[6]/div/div[1]/button/i')
        }
        


        self.longin_test_data = {'渠道商':'houdong','密码':111111,'华元素':'ehys','诺贝尔':'nuobeier','施工方':'caoyuehua'}