from selenium import webdriver
import time
from UI.tools.dw import ElementOperition
from UI.tools.case_config import Test


class DataClass():#页面元素数据类

    def __init__(self):
        self.longin_yuansu = {'账号输入框':('xpath','//input[@placeholder="请输入账号"]')
        ,'密码输入框':('xpath','//input[@placeholder="请输入密码"]')   
        ,'登入按钮':('xpath','//*[@id="app"]/div[2]/div[2]/div[1]/form/button')    
        ,'购物车':('xpath','//*[@id="app"]/div[1]/div/div[1]/div/div[4]/div[1]')    
        ,'诺贝尔店铺':('xpath','//div[@title="诺贝尔华世界店"]') 
        ,'加入购物车':('xpath','//*[@id="saleGroup"]/div[1]/div/div[3]/div[1]/div[1]/div[2]/div/div')    
        ,'勾选第一个商品':('xpath','//*[@id="wrap"]/div[2]/div[1]/div[1]/div/div/div[2]/div/div/div[1]/label/span[1]/span')  
        ,'结算按钮':('xpath','//*[@id="wrap"]/div[2]/div[2]/div[2]/button/span')   
        ,'不开具发票':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[3]/div[1]/div/label[2]/span[1]/span')    
        ,'提交订单按钮':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[6]/div[1]/button[2]/span')   
        ,'支付预付款':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[2]/div[2]/div[2]/span[2]/button[1]/span')    
        ,'支付凭证输入框':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[2]/div[2]/div[2]/div[3]/div[1]/input')   
        ,'上传支付凭证按钮':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[2]/div[2]/div[2]/div[3]/div[2]/button/span') 
        ,'支付金额':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[2]/div[2]/div[2]/div[2]/div[2]/div[2]')
        ,'确认提交':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[3]/div/button')  
        ,'悬停商品':('xpath','//*[@id="saleGroup"]/div[1]/div/div[3]/div[1]/div[1]')   
        ,'经常购买':('xpath','//*[@id="wrap"]/div[1]/div/div[1]/div/div/div/div[1]/div[2]/span')   
        ,'勾选第一个商品':('xpath','//*[@id="wrap"]/div[2]/div[1]/div[1]/div/div[1]/div[2]/div/div/div[1]/label/span[1]/span')   
        ,'结算按钮':('xpath','//*[@id="wrap"]/div[2]/div[2]/div[2]/button')   
        ,'订单信息':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[1]/div/div[1]/div[1]')
        ,'售出订单':('xpath','//div[@title="售出订单"]') 
        ,'订单搜索输入框':('xpath','//*[@id="app"]/div[3]/div[1]/div[2]/div[1]/div[4]/input') 
        ,'查看详情':('xpath','//a[text()="查看详情"]') 
        ,'确认收款':('xpath','//span[text()="确认收款"]') 
        ,'实收金额输入框':('xpath','//*[@id="collectionAmont"]') 
        ,'弹窗确认收款':('xpath','//*[@id="app"]/div[3]/div[2]/div[1]/div/div[11]/div/div[2]/div/div[1]/div/div/div[3]/button[2]/span') 
        ,'判断页面元素':('xpath','//span[@title="买入订单"]')
        ,'关联买入订单':('xpath','//span[@class="active" and text()="买入订单"]')
        ,'付预付款':('xpath','//span[text()="付预付款"]')
        ,'全选':('xpath','//*[@id="wrap"]/div[2]/div[2]/div[1]/div[1]/label/span[1]/span')
        ,'删除':('xpath','//span[text()="删除"]')
        ,'确定':('xpath','//span[text()="确定"]')
        ,'消息':('xpath','//div[text()="消息"]')

        }
        


        self.longin_test_data = {'渠道商':'houdong','密码':111111,'华元素':'ehys','诺贝尔':'nuobeier','施工方':'caoyuehua'}