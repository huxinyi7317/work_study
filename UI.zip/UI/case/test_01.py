import unittest
from selenium import webdriver
import time
from UI.tools.dw import ElementOperition    #行为方法
from UI.tools.case_config import Test   #继承testcase的子类
from UI.po.case_01_shuju import DataClass   #数据类保存数据和页面元素数据

class TestCaseSut(Test):

    
    def test_01(self):
        #登录测试用例
        self.driver.get("http://dev.echronos.com:10460/accounts/login?next=/")

        op = ElementOperition()
        data = DataClass()
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu[0],data=data.longin_test_data['账号'],msg='登入输入框定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu[1],data=data.longin_test_data['密码'],msg='密码输入框定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu[2],data=None,t=False,msg='登入按钮定位失败')
        msg = op.assert_wd(self.driver,data.longin_yuansu[3])
        self.assertTrue(msg,msg='登入用例失败')

    def test_02(self):
        #选择聊天列表第4个对象发送信息
        op = ElementOperition()
        data = DataClass()
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu[4],data=None,t=False,msg='聊天列表定位失败')        
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu[5],data=None,t=False,msg='聊天输入框定位失败')
        ifrm = op.yuansudw(self.driver,yuansu=data.longin_yuansu[6])
        self.driver.switch_to.frame(ifrm)
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu[7],data='1',t=True,msg='聊天信息输入失败')
        self.driver.switch_to.default_content()
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu[8],data=None,t=False,msg='发送按钮定位失败')        

if __name__ == "__main__":
    unittest.main()