import unittest
from selenium import webdriver
import time
import re
from UI.tools.dw import ElementOperition    #行为方法
from UI.tools.case_config import Test   #继承testcase的子类
from UI.po.case_02_shuju import DataClass   #数据类保存数据和页面元素数据
from UI.tools.dome_autoit import WinControl     #windows窗口处理第三方库自定义的方法
from pykeyboard import PyKeyboard   #模拟键盘操作的第三方库


dddata = {}

class TestCaseSut(Test):
    def __init__(self,methodName,url='http://dev.echronos.com:10460',header=False):
        #parame header 控制浏览器有头无头，默认无头
        super(TestCaseSut,self).__init__(methodName)
        self.url = url
        if header:
            options = webdriver.ChromeOptions()
            options.add_argument("--headless")
            self.driver = webdriver.Chrome(executable_path='driver\chromedriver.exe',options=options)

    def test_01(self):
        #渠道商登入下单
        self.driver.get(self.url)
        op = ElementOperition()
        data = DataClass()
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['账号输入框'],data=data.longin_test_data['渠道商'],msg='登入输入框定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['密码输入框'],data=data.longin_test_data['密码'],msg='密码输入框定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['登入按钮'],data=None,t=False,msg='登入按钮定位失败')
        msg,elem = op.assert_wd(self.driver,data.longin_yuansu['购物车'])
        self.assertTrue(msg,msg='登入失败')
        elem.click()
        msg,elem = op.assert_wd(self.driver,data.longin_yuansu['勾选第一个商品'],timeout=5)
        if msg:
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['全选'],data=None,t=False,msg='全选'+'定位失败')
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['删除'],data=None,t=False,msg='删除'+'定位失败')
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['确定'],data=None,t=False,msg='确定'+'定位失败')           
        
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['消息'],data=None,t=False,msg='消息'+'定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['诺贝尔店铺'],t=False,data=None,msg='诺贝尔店铺定位失败')
        op.xuanting(self.driver,yuansu=data.longin_yuansu['悬停商品'])  #鼠标悬停
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['加入购物车'],t=False,data=None,msg='加入购物车定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['购物车'],t=False,data=None,msg='进入购物车定位失败')
        msg,elem = op.assert_wd(self.driver,yuansu=data.longin_yuansu['勾选第一个商品'],timeout=5)
        #如果添加的商品不存在，就刷新页面再次定位，存在直接点勾选
        while not msg:
            self.driver.refresh()
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['勾选第一个商品'],t=False,data=None,msg='勾选第一个商品定位失败')
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['结算按钮'],t=False,data=None,msg='结算按钮定位失败')
        else:
            elem.click()
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['结算按钮'],t=False,data=None,msg='结算按钮定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['不开具发票'],t=False,data=None,msg='不开具发票定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['提交订单按钮'],t=False,data=None,msg='提交订单按钮定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['支付预付款'],t=False,data=None,msg='支付预付款定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['支付凭证输入框'],t=True,data='testhxy',msg='支付凭证输入框定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['上传支付凭证按钮'],t=False,data=None,msg='上传支付凭证按钮定位失败')
        win = WinControl(title='打开')
        time.sleep(2)
        #调用第三方库定位windows窗口
        try:
            win.controlSend(control='Edit1',send_text=r"D:\pytest_test\UI\timg.jpg",mode=1)
            win.controlClick('Button1')
        except:
            # win = WinControl(title='打开',text='确定')
            # win.controlClick('Button1')
            # win.controlSend(control='Edit1',send_text=r"D:\pytest_test\UI\timg.jpg",mode=1)
            # win.controlClick('Button1')
            print('输入的文件不存在')
        msg,elem = op.assert_wd(self.driver,data.longin_yuansu['支付金额'])
        if msg:
            global _ddje
            _ddje = elem.get_attribute('textContent')
            # print(_ddje)
        time.sleep(1)
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['确认提交'],t=False,data=None,msg='确认提交定位失败')
        msg,elem = op.assert_wd(self.driver,data.longin_yuansu['判断页面元素'])
        
        if msg:
            try:
                msg,elem = op.assert_wd(self.driver,data.longin_yuansu['订单信息'])
                item = elem.get_attribute('textContent')
                global _ddid
                _ddid = re.search(r'订单编号：(.*)',item).group(1)
                dddata['渠道商买入订单号']=_ddid
                print(item,_ddid)
            except:
                print('订单信息有误'+item)
            
        print('渠道商下单支付预付款完成')

    def test_02(self):
        #华元素确认收款
        global _ddid,_ddje
        if _ddid:
            self.driver.get(self.url)
            op = ElementOperition()
            data = DataClass()
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['账号输入框'],data=data.longin_test_data['华元素'],msg='登入输入框定位失败')
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['密码输入框'],data=data.longin_test_data['密码'],msg='密码输入框定位失败')
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['登入按钮'],data=None,t=False,msg='登入按钮定位失败')
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['售出订单'],t=False,data=None,msg='售出订单'+'定位失败')   
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['订单搜索输入框'],t=True,data=_ddid,msg='订单搜索输入框'+'定位失败')   
            #回车
            k = PyKeyboard()
            k.tap_key(k.enter_key)

            # op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['查看详情'],t=False,data=None,msg='查看详情'+'定位失败')
            time.sleep(1)
            item = self.driver.window_handles
            self.driver.switch_to.window(item[-1])
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['确认收款'],t=False,data=None,msg='确认收款'+'定位失败')   
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['实收金额输入框'],t=True,data=_ddje,msg='实收金额输入框'+'定位失败')   
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['弹窗确认收款'],t=False,data=None,msg='弹窗确认收款'+'定位失败') 
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['关联买入订单'],t=False,data=None,msg='关联买入订单'+'定位失败')
            #窗口跳转
            time.sleep(1)
            item = self.driver.window_handles
            self.driver.switch_to.window(item[-1]) 
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['付预付款'],t=False,data=None,msg='付预付款'+'定位失败') 
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['支付凭证输入框'],t=True,data='testhxy',msg='支付凭证输入框定位失败')
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['上传支付凭证按钮'],t=False,data=None,msg='上传支付凭证按钮定位失败')
            win = WinControl(title='打开')
            time.sleep(2)
            #调用第三方库定位windows窗口
            try:
                win.controlSend(control='Edit1',send_text=r"D:\pytest_test\UI\timg.jpg",mode=1)
                win.controlClick('Button1')
            except:
                print('输入的文件路径不存在')
            msg,elem = op.assert_wd(self.driver,data.longin_yuansu['支付金额'])
            if msg:
                _ddje = elem.get_attribute('textContent')
                # print(_ddje)
            time.sleep(1)
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['确认提交'],t=False,data=None,msg='确认提交定位失败')
            msg,elem = op.assert_wd(self.driver,data.longin_yuansu['判断页面元素'])
            
            if msg:
                try:
                    msg,elem = op.assert_wd(self.driver,data.longin_yuansu['订单信息'])
                    item = elem.get_attribute('textContent')
                    _ddid = re.search(r'订单编号：(.*)',item).group(1)
                    dddata['华元素买入订单号']=_ddid

                    # print(item,_ddid)
                except:
                    print('订单信息有误'+item)
                print('\n华元素已向厂家支付预付款')
            else:
                print('\n华元素买入订单生成失败')
    def test_03(self):
        #诺贝尔确认收款
        global _ddid,_ddje
        if _ddid:
            self.driver.get(self.url)
            op = ElementOperition()
            data = DataClass()
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['账号输入框'],data=data.longin_test_data['诺贝尔'],msg='登入输入框定位失败')
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['密码输入框'],data=data.longin_test_data['密码'],msg='密码输入框定位失败')
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['登入按钮'],data=None,t=False,msg='登入按钮定位失败')
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['售出订单'],t=False,data=None,msg='售出订单'+'定位失败')   
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['订单搜索输入框'],t=True,data=_ddid,msg='订单搜索输入框'+'定位失败')   
            #回车
            k = PyKeyboard()
            k.tap_key(k.enter_key)

            # op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['查看详情'],t=False,data=None,msg='查看详情'+'定位失败')
            time.sleep(2)
            item = self.driver.window_handles
            self.driver.switch_to.window(item[-1])
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['确认收款'],t=False,data=None,msg='确认收款'+'定位失败')   
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['实收金额输入框'],t=True,data=_ddje,msg='实收金额输入框'+'定位失败')   
            op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['弹窗确认收款'],t=False,data=None,msg='弹窗确认收款'+'定位失败') 

            msg,elem = op.assert_wd(self.driver,data.longin_yuansu['判断页面元素'])
            if msg:
                try:
                    msg,elem = op.assert_wd(self.driver,data.longin_yuansu['订单信息'])
                    item = elem.get_attribute('textContent')
                    _ddid = re.search(r'订单编号：(.*)',item).group(1)
                    dddata['厂商售出订单号']=_ddid

                    # print(item,_ddid)
                except:
                    print('订单信息有误'+item)
            print('\n厂家确认收款')
if __name__ == "__main__":
    unittest.main()
