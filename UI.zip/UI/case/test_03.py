import unittest
from selenium import webdriver
import time
import re
from UI.tools.dw import ElementOperition    #行为方法
from UI.tools.case_config import Test   #继承testcase的子类
from UI.po.case_03_shuju import DataClass   #数据类保存数据和页面元素数据
from UI.tools.dome_autoit import WinControl     #windows窗口处理第三方库自定义的方法
from pykeyboard import PyKeyboard   #模拟键盘操作的第三方库



class TestCaseSut(Test):
    def __init__(self,methodName,url='http://192.168.188.61:8080/',header=False):
        #parame header 控制浏览器有头无头，默认无头
        super(TestCaseSut,self).__init__(methodName)
        self.url = url
        if header:
            options = webdriver.ChromeOptions()
            options.add_argument("--headless")
            self.driver = webdriver.Chrome(executable_path='driver\chromedriver.exe',options=options)

    def test_01(self):
        #智能招标
        self.driver.get(self.url)
        op = ElementOperition()
        data = DataClass()
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['账号输入框'],data=data.longin_test_data['华元素'],msg='登入输入框定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['密码输入框'],data=data.longin_test_data['密码'],msg='密码输入框定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['登入按钮'],data=None,t=False,msg='登入按钮定位失败')
        msg,elem = op.assert_wd(self.driver,data.longin_yuansu['购物车'])
        self.assertTrue(msg,msg='登入失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['智能招标'],t=False,data=None,msg='智能招标定位失败')
        hd = self.driver.window_handles
        self.driver.switch_to.window(hd[-1])
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['新建智能招标'],t=False,data=None,msg='新建智能招标'+'定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['招标名称'],t=True,data='testhxy',msg='招标名称'+'定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['项目名称'],t=True,data='testhxy',msg='项目名称'+'定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['回标截止时间'],t=True,data='2021-01-10 00:00:00',msg='回标截止时间'+'定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['备注信息'],t=True,data='testhxy',msg='备注信息'+'定位失败') 
        msg,elem = op.assert_wd(self.driver,data.longin_yuansu['副文本编辑器'])
        self.driver.switch_to.frame(elem)
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['副文本编辑区域'],t=True,data='testhxy',msg='上传招标公告'+'定位失败')
        self.driver.switch_to.default_content()
        filepath = r'D:\pytest_test\UI\timg.jpg'
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['上传招标公告'],t=True,data=filepath,msg='上传招标公告'+'定位失败')
        time.sleep(1)
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['上传招标邀请函'],t=True,data=filepath,msg='上传招标邀请函'+'定位失败')
        time.sleep(1)
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['上传招标文件'],t=True,data=filepath,msg='上传招标文件'+'定位失败')
        time.sleep(1)
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['上传招标技术标准'],t=True,data=filepath,msg='上传招标技术标准'+'定位失败')
        time.sleep(1)
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['下一步'],t=False,data=None,msg='下一步'+'定位失败')
        msg,elem = op.assert_wd(self.driver,data.longin_yuansu['上一步'])
        self.assertTrue(msg,msg='发标失败')
        print('=====发标成功======')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['商品分类'],t=False,data=None,msg='上传招标公告'+'定位失败')
        time.sleep(2)
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['精装材料'],t=False,data=None,msg='精装材料'+'定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['瓷砖'],t=False,data=None,msg='瓷砖'+'定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['抛光砖'],t=False,data=None,msg='抛光砖'+'定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['添加产品'],t=False,data=None,msg='添加产品'+'定位失败')
        # op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['test_'],t=False,data=None,msg='test_'+'定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['商品单位'],t=True,data='平方米',msg='平方米'+'定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['室内地砖'],t=False,data=None,msg='室内地砖'+'定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['内墙'],t=False,data=None,msg='内墙'+'定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['200*200'],t=False,data=None,msg='200*200'+'定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['300*450'],t=False,data=None,msg='300*450'+'定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['确定'],t=False,data=None,msg='确定'+'定位失败')
        op.yuansu_send_zaozuo(self.driver,yuansu=data.longin_yuansu['提交'],t=False,data=None,msg='提交'+'定位失败')
        print('====添加产品成功====')

if __name__ == "__main__":
    unittest.main()