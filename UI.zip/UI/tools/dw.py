from selenium.webdriver.support.ui import WebDriverWait
from UI.tools.case_config import Test
from selenium.webdriver.common.action_chains import ActionChains
from time import sleep

class ElementOperition(Test):
    def yuansudw(self,driver,yuansu,timeout=30):

        '''
        元素定位传递格式:('xpath','元素的xpath')
        '''
        return WebDriverWait(driver=driver,timeout=timeout).until(lambda s: s.find_element(*yuansu))

    def assert_wd(self,driver,yuansu,timeout=30):
        #判断元素是否存在，存在返回True，不存在返回False
        try:
            elem = self.yuansudw(driver,yuansu,timeout=timeout)
            return True,elem
        except:
            return False,None
        

    def yuansu_send_zaozuo(self,driver,yuansu,data,msg,t=True,timeout=30):
        # driver = 浏览器的句柄
        # yuansu = (定位方式，要素) --> ('xpath','//div/xxx')
        # t=True默认对元素进行输入操作，否则进行点击
        # data = 要输入的内容
        # msg = 断言报错信息
            if t == True:
                status = self.assert_wd(driver= driver,yuansu=yuansu,timeout=timeout)
                self.assertTrue(status,msg=msg)
                cz = self.yuansudw(driver= driver,yuansu=yuansu,timeout=timeout)
                cz.send_keys(data)

            else:
                status = self.assert_wd(driver= driver,yuansu=yuansu,timeout=timeout)
                self.assertTrue(status,msg=msg)
                cz = self.yuansudw(driver= driver,yuansu=yuansu,timeout=timeout)
                cz.click()
    def xuanting(self,driver,yuansu,time=1):
        #鼠标悬停方法，查找需要鼠标停留元素上才会出现的元素
        #yuansu = 参数是需要悬停的元素
        #time = 悬停时间
        move = self.yuansudw(driver,yuansu)
        ActionChains(driver).move_to_element(move).perform()
        sleep(time)

if __name__ == "__main__":
    pass