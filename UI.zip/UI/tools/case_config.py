import unittest
from selenium import webdriver
import time





class Test(unittest.TestCase):
    #类启动运行该方法
    @classmethod
    def setUpClass(cls):
        try:
            cls.driver = webdriver.Chrome(executable_path='driver\chromedriver.exe') 
        except Exception as e:
            print('驱动初始化失败'+e)
    #类停止运行该方法
    @classmethod
    def tearDownClass(cls):
        cls.driver.quit()


if __name__ == "__main__":
    pass